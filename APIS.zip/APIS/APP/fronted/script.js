function fetchAllTasks(){
    fetch("../index.php?action=getAllTasks")
    .then((response) => response.json())
    .then((data) => {
        const taskList = document.getElementById("task-list");
        taskList.innerHTML = "";
        data.forEach((task) => {
            const listItem = document.createElement("li");
            listItem.textContent = task.title;
            taskList.appendChild(listItem);
        });
    })
    .catch((error) => console.error("Error:", error));
}
function searchTask() 
{
    const taskId = document.getElementById("task-id").value;
    if (!taskId){
        alert("por favor, ingrese un ID de tarea.");
        return;
    }
    fetch(`../index.php?action=getTaskById&id=${taskId}`)

    // fetch("../index.php?action=getTaskById&id=${taskId}")
        .then((response) => response.json())
        .then((data) => {
            const taskDetails = document.getElementById("task-details");
            taskDetails.innerHTML = "";
            if (data.message){
                alert(data.message);
            } else {
                const taskInfo = document.createElement("div");
                taskInfo.innerHTML = `<strong>ID:</strong> ${data.id}<br><strong>Titulo:</strong> ${data.title}`;

                taskDetails.appendChild(taskInfo);
            }
        })
        .catch((error) => console.error("Error:", error));
}
fetchAllTasks();