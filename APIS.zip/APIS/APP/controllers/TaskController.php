<?php
class TaskController
{
    private $model;

    public function __construct($model)
    {
        $this->model = $model;
    }

    public function getAllTasks()
    {
        $tasks = $this->model->getAllTasks();
        return json_encode($tasks);
    }

    public function getTaskById($id)
    {
        $task = $this->model->getTaskById($id);
        if ($task){
            return json_encode($task);
        } else {
            return json_encode(['message' => 'Tarea no encontrada']);
        }
    }
    
    // Otros metodos para agregar, actualizar y eliminar tareas
}